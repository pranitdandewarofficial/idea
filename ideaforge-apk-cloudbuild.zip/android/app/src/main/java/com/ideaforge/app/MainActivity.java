package com.ideaforge.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
